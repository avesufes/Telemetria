var searchData=
[
  ['include_5fscrolling',['INCLUDE_SCROLLING',['../_s_s_d1306_ascii_8h.html#ac0de102de39ccaab02096339b6ea9ec3',1,'SSD1306Ascii.h']]],
  ['initial_5fscroll_5fmode',['INITIAL_SCROLL_MODE',['../_s_s_d1306_ascii_8h.html#a0d9ee90aff33dec356c3f4a059618bac',1,'SSD1306Ascii.h']]]
];
